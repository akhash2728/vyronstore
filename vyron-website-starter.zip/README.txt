VYRON WEBSITE STARTER

Files:
- index.html: the complete responsive starter website.

Before publishing:
1. Replace YOUR-EMAIL@example.com with your real contact email (search in index.html).
2. Replace the sample product names/text and the CSS placeholder artwork with your real products/photos.
3. The shop currently says COMING SOON. It is a brand landing page, not a working checkout/store.
4. Do not advertise materials, sustainability claims, delivery promises or prices until you can confirm them.

Free publishing:
- You can publish the site using GitHub Pages or Netlify's free static hosting tier (availability/limits can change).
- Upload index.html (or the whole folder) to your chosen host.
- In that host's domain settings, add vyronstore.co.uk and follow its exact DNS instructions at the company where you bought the domain.
- Keep the DNS records shown by the host; do not guess A/CNAME records. DNS changes can take time to update.

A custom domain may require a domain renewal fee even if hosting is free.
