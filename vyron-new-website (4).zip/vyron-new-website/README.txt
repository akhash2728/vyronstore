VYRON UPDATED WEBSITE

Upload index.html to the ROOT of your GitHub repository:
https://github.com/akhash2728/vyronstore

Replace the old index.html, then commit the change to the main branch.
Keep your existing GitHub Pages custom domain and Wix DNS records unchanged.
After deployment, check https://vyronstore.co.uk

This is a visual brand / coming-soon website. It does not include a shopping cart,
checkout, product inventory or payment processing.

Check all contact/social links before publishing. The clothing visuals are CSS mockups,
not photographs of finished stock.
